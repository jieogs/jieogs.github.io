#!/system/bin/sh
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

CONFIG_FILE="./asxsky_config.conf"

a() {
    echo -e "${YELLOW}\n开始一键安装所需依赖...${NC}"
    if command -v pkg &> /dev/null; then
        pkg install -y curl dnsutils bc proxychains4
    elif command -v apt &> /dev/null; then
        apt install -y curl dnsutils bc proxychains4
    else
        echo -e "${RED}未检测到pkg或apt包管理器，请手动安装依赖：curl、dnsutils、bc、proxychains4${NC}"
        return 1
    fi
    echo -e "${GREEN}依赖安装完成！${NC}"
}

b() {
    DEPS=("curl" "dnsutils" "bc" "proxychains4")
    MISSING_DEPS=()
    for dep in "${DEPS[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            MISSING_DEPS+=("$dep")
        fi
    done
    if [ ${#MISSING_DEPS[@]} -gt 0 ]; then
        echo -e "${YELLOW}检测到缺少依赖：${MISSING_DEPS[*]}，是否一键安装？(y/n)${NC}"
        read -r INSTALL
        if [ "$INSTALL" = "y" ] || [ "$INSTALL" = "Y" ]; then
            a
        else
            echo -e "${RED}依赖未安装，部分功能将不可用！${NC}"
        fi
    else
        echo -e "${GREEN}所有依赖已安装，功能完整可用${NC}"
    fi
}

c() {
    clear
    echo -e "${RED}=============================================${NC}"
    echo -e "${RED}  AAAAA   SSSSS   XXXXX   XXXXX   SSSSS   K   K  YYYYYY${NC}"
    echo -e "${RED}  A   A  S       X   X   X   X  S       K  K   Y     Y${NC}"
    echo -e "${RED}  AAAAA   SSS    XXXXX   XXXXX   SSS    KKK    Y     Y${NC}"
    echo -e "${RED}  A   A       S  X   X  X   X       S  K  K   Y     Y${NC}"
    echo -e "${RED}  A   A  SSSSS  X   X  X   X  SSSSS  K   K   YYYYYY${NC}"
    echo -e "${RED}=============================================${NC}"
    echo -e "\n${YELLOW}【风险提示】${NC}"
    echo "1. 本脚本仅用于合法网络测试，禁止用于未授权的IP/网址探测"
    echo "2. 滥用可能违反法律法规，使用者需自行承担法律责任"
    echo "3. 随机IP功能需确保网络环境合规，避免干扰正常网络秩序"
    echo -e "\n${RED}是否已阅读并同意以上风险条款？(y/n)${NC}"
    read -r AGREE
    if [ "$AGREE" != "y" ] && [ "$AGREE" != "Y" ]; then
        echo -e "${RED}您已拒绝风险条款，脚本退出${NC}"
        exit 0
    fi
}

d() {
    if [ -f "$CONFIG_FILE" ]; then
        echo -e "${GREEN}\n正在读取配置文件...${NC}"
        source "$CONFIG_FILE"
        echo -e "线程数：$THREAD_NUM"
        echo -e "请求频率：$REQ_INTERVAL 秒"
        echo -e "随机IP功能：$RANDOM_IP_ENABLE"
    else
        echo -e "${YELLOW}\n未找到配置文件，将使用默认值${NC}"
        THREAD_NUM=5
        REQ_INTERVAL=1
        RANDOM_IP_ENABLE="disable"
        PROXY_POOL=("socks5://192.168.1.100:1080" "http://202.xx.xx.xx:8080")
    fi
}

e() {
    echo -e "${GREEN}\n正在保存配置...${NC}"
    cat > "$CONFIG_FILE" << EOF
THREAD_NUM=$THREAD_NUM
REQ_INTERVAL=$REQ_INTERVAL
RANDOM_IP_ENABLE=$RANDOM_IP_ENABLE
EOF
    echo -e "${GREEN}配置已保存到 $CONFIG_FILE${NC}"
}

f() {
    if [ "$RANDOM_IP_ENABLE" = "enable" ] && [ "$(id -u)" -ne 0 ]; then
        echo -e "${RED}启用随机IP功能需要Root权限，请先执行 'su' 后重新运行脚本${NC}"
        exit 1
    fi
}

g() {
    f
    echo -e "${BLUE}\n请输入目标IP/网址（例如：https://www.baidu.com 或 192.168.1.1）：${NC}"
    read -r TARGET
    if [ -z "$TARGET" ]; then
        echo -e "${RED}错误：目标不能为空${NC}"
        return 1
    fi

    echo -e "${BLUE}正在以 ${THREAD_NUM} 线程、${REQ_INTERVAL} 秒间隔请求 $TARGET...${NC}"
    echo -e "${YELLOW}按 Ctrl+C 停止请求${NC}"

    while true; do
        for i in $(seq 1 $THREAD_NUM); do
            if [ "$RANDOM_IP_ENABLE" = "enable" ]; then
                RAND_PROXY=${PROXY_POOL[$((RANDOM % ${#PROXY_POOL[@]}))]}
                proxychains4 -q -x "$RAND_PROXY" curl -s "$TARGET" -o /dev/null && echo -e "${GREEN}[线程$i] 请求成功（代理IP：$RAND_PROXY）${NC}" || echo -e "${RED}[线程$i] 请求失败${NC}"
            else
                curl -s "$TARGET" -o /dev/null && echo -e "${GREEN}[线程$i] 请求成功${NC}" || echo -e "${RED}[线程$i] 请求失败${NC}"
            fi
        done
        sleep "$REQ_INTERVAL"
    done
}

h() {
    echo -e "${BLUE}\n请输入需解析的网址（例如：www.baidu.com）：${NC}"
    read -r URL
    if [ -z "$URL" ]; then
        echo -e "${RED}错误：网址不能为空${NC}"
        return 1
    fi

    echo -e "${GREEN}\n正在解析 $URL 的IP地址...${NC}"
    nslookup "$URL" | grep -E 'Address: [0-9.]+' | awk '{print "IP地址：" $2}'
}

i() {
    d
    while true; do
        clear
        echo -e "${BLUE}=======================================${NC}"
        echo -e "${BLUE}              ASXSKY - 功能菜单         ${NC}"
        echo -e "${BLUE}=======================================${NC}"
        echo -e "当前配置：线程数=${GREEN}$THREAD_NUM${NC} | 频率=${GREEN}$REQ_INTERVAL秒${NC} | 随机IP=${GREEN}$RANDOM_IP_ENABLE${NC}"
        echo -e "\n${YELLOW}请选择功能（输入数字）：${NC}"
        echo "1. 多线程请求目标IP/网址（启用随机IP时需Root）"
        echo "2. 修改配置（线程数、频率、随机IP）"
        echo "3. 解析网址的IP地址"
        echo "4. 一键安装依赖库"
        echo "5. 退出脚本"
        echo -e "${BLUE}\n请输入选择：${NC}"
        read -r CHOICE

        case $CHOICE in
            1)
                g
                echo -e "${YELLOW}\n按任意键返回菜单...${NC}"
                read -r
                ;;
            2)
                echo -e "${BLUE}\n修改配置：${NC}"
                echo -e "当前线程数：$THREAD_NUM，请输入新线程数（1-20）：${NC}"
                read -r NEW_THREAD
                if [ "$NEW_THREAD" -ge 1 ] && [ "$NEW_THREAD" -le 20 ]; then
                    THREAD_NUM=$NEW_THREAD
                else
                    echo -e "${RED}线程数无效，保持原值${NC}"
                fi

                echo -e "当前请求频率：$REQ_INTERVAL 秒，请输入新频率（0.1-10）：${NC}"
                if [ $(echo "$NEW_INTERVAL >= 0.1 && $NEW_INTERVAL <= 10" | bc) -eq 1 ]; then
                    REQ_INTERVAL=$NEW_INTERVAL
                else
                    echo -e "${RED}频率无效，保持原值${NC}"
                fi

                echo -e "当前随机IP功能：$RANDOM_IP_ENABLE，请输入新状态（enable/disable）：${NC}"
                read -r NEW_RANDOM
                if [ "$NEW_RANDOM" = "enable" ] || [ "$NEW_RANDOM" = "disable" ]; then
                    RANDOM_IP_ENABLE=$NEW_RANDOM
                else
                    echo -e "${RED}状态无效，保持原值${NC}"
                fi

                e
                echo -e "${YELLOW}\n按任意键返回菜单...${NC}"
                read -r
                ;;
            3)
                h
                echo -e "${YELLOW}\n按任意键返回菜单...${NC}"
                read -r
                ;;
            4)
                a
                echo -e "${YELLOW}\n按任意键返回菜单...${NC}"
                read -r
                ;;
            5)
                echo -e "${GREEN}\n脚本退出，感谢使用！${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}\n无效选择，请重新输入！${NC}"
                echo -e "${YELLOW}按任意键返回菜单...${NC}"
                read -r
                ;;
        esac
    done
}

b
c
i
